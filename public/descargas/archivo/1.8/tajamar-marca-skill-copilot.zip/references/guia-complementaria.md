# Marca Tajamar: guía complementaria

Complemento de la skill tajamar-marca para Microsoft 365 Copilot, versión 1.8 (27 de noviembre de 2026). Las reglas generales están en SKILL.md.

## Manifiesto

> A las personalidades singulares.
> A los que no se sienten parte de una masa.
> A los que son serios en ser espontáneos.
> A los que sienten que son más de una sola cosa.
> A los que rompen con lo monocorde, con lo igual.
> A los que saben que su diferencia individual suma.
> A los que creen que su diferencia es lo que une, no lo que separa.
> A los que piensan por sí mismos.
> A los que son como son.
> libresypunto.

Por qué esta marca: para afrontar una nueva etapa con fuerza y atrevimiento, orgullosos de lo que somos, y llegar a todos nuestros públicos. No es solo un cambio de identidad visual, sino una visión estratégica: confiamos en nuestras posibilidades y nos adaptamos al futuro desde nuestra esencia. Somos distintos y tenemos derecho a ser distintos. Somos libres, y punto. Es una marca idealista, abierta y libre, que se entrega con valentía, sin paradigmas establecidos: la marca de un privado-público.

## Color

El negro es el color de la firma: transmite seguridad y elegancia sin necesidad de llamar la atención. A su alrededor hay cuatro gamas que salen del propio centro.

Reglas:
- **Texto sobre blanco:** solo con los tonos marcados «texto» en la tabla. Los tonos claros y vivos son campos de color y llevan texto negro encima.
- **Un color por área:** si una subárea toma un color, el resto de sus piezas va en ese color o en tintas de su gama.
- **Por área:** Alumni prefiere tierras y oscuros. Infantil usa el color a fondo, salvo en la cabecera web. FP+ usa el negro como base.
- **Tintas:** cada color se puede usar en sus gradaciones, igual que el negro va del 10 % al 100 %.

En la columna «Uso», «texto» significa que el tono vale para texto sobre blanco (contraste ≥ 4.5:1) y «campo» que solo vale como fondo de color. La columna «Texto encima» indica el color del texto que va sobre ese tono.

| Gama | Nombre | HEX | RGB | Pantone | CMYK | Uso | Texto encima |
|---|---|---|---|---|---|---|---|
| Negro | negro | #000000 | 0, 0, 0 | PANTONE Process Black | C0 M0 Y0 K100 | texto | blanco |
| Negro | gris-90 | #1A1A1A | 26, 26, 26 | — | K90 | texto | blanco |
| Negro | gris-80 | #333333 | 51, 51, 51 | — | K80 | texto | blanco |
| Negro | gris-70 | #4D4D4D | 77, 77, 77 | — | K70 | texto | blanco |
| Negro | gris-60 | #666666 | 102, 102, 102 | — | K60 | texto | blanco |
| Negro | gris-50 | #808080 | 128, 128, 128 | — | K50 | campo | negro |
| Negro | gris-40 | #999999 | 153, 153, 153 | — | K40 | campo | negro |
| Negro | gris-30 | #B3B3B3 | 179, 179, 179 | — | K30 | campo | negro |
| Negro | gris-20 | #CCCCCC | 204, 204, 204 | — | K20 | campo | negro |
| Negro | gris-10 | #E6E6E6 | 230, 230, 230 | — | K10 | campo | negro |
| Cielo | cielo-1 | #212844 | 33, 40, 68 | PANTONE 533 C | C95 M80 Y45 K50 | texto | blanco |
| Cielo | cielo-2 | #1C4F90 | 28, 79, 144 | PANTONE 7686 C | C95 M70 Y5 K0 | texto | blanco |
| Cielo | cielo-3 | #446CA9 | 68, 108, 169 | PANTONE 7683 C | C80 M50 Y0 K0 | texto | blanco |
| Cielo | cielo-4 | #40B4E5 | 64, 180, 229 | PANTONE 298 C | C70 M10 Y0 K0 | campo | negro |
| Cielo | cielo-5 | #77CAE6 | 119, 202, 230 | PANTONE Blue 0821 C | C55 M0 Y0 K0 | campo | negro |
| Zona Verde | verde-1 | #005740 | 0, 87, 64 | PANTONE 7484 C | C100 M40 Y95 K30 | texto | blanco |
| Zona Verde | verde-2 | #2D7150 | 45, 113, 80 | PANTONE 555 C | C85 M30 Y100 K15 | texto | blanco |
| Zona Verde | verde-3 | #45AB34 | 69, 171, 52 | PANTONE 361 C | C75 M0 Y100 K0 | campo | negro |
| Zona Verde | verde-4 | #78B72A | 120, 183, 42 | PANTONE 368 C | C50 M0 Y100 K0 | campo | negro |
| Zona Verde | verde-5 | #D8C722 | 216, 199, 34 | PANTONE 611 C | C30 M0 Y90 K0 | campo | negro |
| Ladrillo | ladrillo-1 | #E53B2F | 229, 59, 47 | PANTONE 179 C | C0 M90 Y85 K0 | campo | negro |
| Ladrillo | ladrillo-2 | #DD6014 | 221, 96, 20 | PANTONE 1595 C | C0 M70 Y95 K0 | campo | negro |
| Ladrillo | ladrillo-3 | #F18A2D | 241, 138, 45 | PANTONE 715 C | C0 M50 Y85 K0 | campo | negro |
| Ladrillo | ladrillo-4 | #F7B332 | 247, 179, 50 | PANTONE 143 C | C0 M35 Y85 K0 | campo | negro |
| Ladrillo | ladrillo-5 | #FFE01C | 255, 224, 28 | PANTONE 107 C | C0 M10 Y90 K0 | campo | negro |
| Barro | barro-1 | #412020 | 65, 32, 32 | PANTONE 4975 C | C50 M80 Y70 K80 | texto | blanco |
| Barro | barro-2 | #76391B | 118, 57, 27 | PANTONE 168 C | C35 M75 Y95 K45 | texto | blanco |
| Barro | barro-3 | #8F481F | 143, 72, 31 | PANTONE 1615 C | C35 M65 Y95 K35 | texto | blanco |
| Barro | barro-4 | #C88A3C | 200, 138, 60 | PANTONE 7510 C | C20 M45 Y80 K5 | campo | negro |
| Barro | barro-5 | #DCB38D | 220, 179, 141 | PANTONE 727 C | C15 M30 Y50 K5 | campo | negro |

Qué representa cada gama: **Negro** es la firma. **Cielo** son los azules, el cielo y la espiritualidad. **Zona Verde** son las zonas verdes del centro. **Ladrillo** son los rojos y naranjas, el ladrillo que construimos. **Barro** son las tierras, el barro histórico en el que crecimos.

## Fotografía

Se buscan momentos de verdad, no posados: una sonrisa, un atrevimiento, un esfuerzo, un momento creativo. Vale una foto de móvil si tiene buena luz y no es un posado. Cada uno, alumnos, padres y profesores, vive su libertad a su manera: esos momentos espontáneos son los que hay que capturar.

Que se nos vea:
- **Optimistas:** humanos y positivos. Soñamos en color.
- **Espontáneos:** abiertos a no parecer iguales que todos, con ganas de compartirnos.
- **Creativos:** humanistas y comunicadores profundos, sin miedo a nuestros valores.
- **Atrevidos:** capaces de atrevernos. Divertidos. ¡Y expresivos!

Qué buscar:
- **Primeros planos:** gestos expresivos y no fiscalizados.
- **Naturalidad:** cualquier momento real con buena luz.
- **Mundo exterior:** aire libre, naturaleza, barrio, vida.
- **Diversidad:** caracteres distintos, celebrados con naturalidad. Las composiciones con muchas personas transmiten pluralidad y cercanía.

Antes de elegir una foto, pregúntate:
- ¿Entrega algo a los demás?
- ¿Hay atrevimiento?
- ¿Es un acto espontáneo y libre?
- ¿Refleja heterogeneidad?
- ¿Hay algo de caos ordenado?
- ¿Sería creíble con una fecha exacta?
- ¿Es fronteriza? ¿Es valiente?
- ¿Inspira apertura?
- ¿Es tan normal y espontánea como la vida?

Usa solo imágenes con derechos y permisos, con especial cuidado con los menores. Nunca fotos sacadas de internet. No generes con IA fotos que se presenten como reales del centro.

Las fotos de Tajamar (el reportaje de 2026 y el archivo histórico, de los años 50 a los 90) las custodia Comunicación: pídelas a comunicacion@tajamar.es indicando qué buscas y para qué pieza. La web de marca solo enseña una muestra y no sirve para descargarlas.

## Look & feel

La seriedad del escudo va acompañada de un mundo expresivo. Todo con medida, porque abusar de ello canibaliza la marca: hay que ser serios en no saturar de caos. A veces la frase sola ya basta.

- **Texto a mano alzada:** sobre foto o color corporativo, en blanco y sin mezclar colores. Valen caligrafías, tamaños y edades distintas, tachados y subrayados. El color lo pone el fondo, salvo con fotos en blanco y negro.
- **Dibujos de alumnos:** reales siempre que se pueda, sobre foto o masa de color. Grafitis hechos a medida, con inspiración de rotulador o boli.
- **Manchones:** borrones de boli o de goma, manchas de café.
- **Gráficos a mano:** tipo pizarra, esquemas y gráficos como los de clase. En Word o PowerPoint, mejor un trazo a mano que las flechas y formas predefinidas.

## Aplicaciones

### Papelería

- **Carta (A4):** escudo a 25 mm del borde superior y del izquierdo, con 16 mm de ancho. Texto en Avenir Book 10 pt, con 41 mm de margen a cada lado. Pie a 10 mm del borde inferior: emisor en Avenir Black 7 pt y dirección en Avenir Book 7 pt. Una versión por etapa (Infantil, Primaria, Secundaria, FP+), con un dibujo de alumno en el margen izquierdo. En FP+, el emisor es «Tajamar» y el descriptor FP+ va arriba a la derecha. Papel Century Splendorgel Extra White 115 g.
- **Sobre americano (220 × 110 mm):** escudo arriba a la izquierda y remite debajo, en Avenir Black y Book 7 pt. Una versión por etapa; la solapa puede llevar dibujos de alumnos (en FP+, negra con el descriptor).
- **Tarjeta de visita (90 × 55 mm):** frontal con escudo arriba y los datos sobre un bloque de color corporativo (mejor si las tarjetas cambian de color; ejemplos: Infantil PANTONE 368 C, Primaria PANTONE 143 C, Secundaria PANTONE 7683 C, FP+ negro). Trasera con dibujos o ilustraciones de alumnos acordes a la etapa. Nombre, cargo y datos en Avenir Book 7 pt; la web en Avenir Black 7 pt. El cargo explicita el área («Directora Educación Infantil»). Emisor: «Colegio Tajamar»; en FP+, «Tajamar» + «FP + Professional Education». Estucado mate 300 g, plastificado mate a dos caras.
- **Carpeta (24 × 32 cm cerrada):** díptico, con o sin bolsillo interior de 10 cm. Portada en color corporativo pleno con el escudo en blanco y el logotipo abajo, o en blanco con un escudo libre.
- **Dirección institucional:** Colegio Tajamar, C/ Pío Felipe, 12 · 28038 Vallecas Madrid · tajamar.es.

### Plantillas descargables

En https://brand.tajamar.es/#plantillas hay plantillas listas para usar: cartas en Word por etapa y área (estándar, Infantil, Primaria, Secundaria, FP+, Club Deportivo, AMPA), presentación corporativa en PowerPoint, 17 carteles en Word sobre la gama oficial, modelo de examen, hojas de Secretaría y un generador de firma de correo con los pasos para añadirla en Gmail y Outlook. Recomienda siempre partir de una plantilla antes de diseñar desde cero. Los carteles se imprimen con «Imprimir colores e imágenes de fondo» activado en Word.

### Pantallas

- **Presentaciones:** portada con escudo arriba a la izquierda, título, subtítulo y fecha. Portadillas de sección a color pleno o con ilustración. Índice numerado (01_Uno, 02_Dos…). Interiores con texto y elementos gráficos, llamadas de atención (con libresypunto) y combinaciones de texto, foto y gráfico.
- **Firma de correo:** a la izquierda, el escudo (40 px) o la imagen del área (escudo y dibujo: Alumni, Bachillerato, Club Deportivo, FP+, Fundación, Infantil, Primaria, Secretaría, Secundaria; 92 px). Las imágenes de área se pueden combinar con cualquier vertical, salvo las de Fundación, que solo puede usar Fundación Tajamar. A la derecha, alineado arriba: todo en Verdana y en los colores de la paleta: nombre en negrita negro (#000000); cargo y área en negrita gris-60 (#666666), unidos por « · »; teléfono «(+34) 91 477 25 00», seguido de « | Ext.: 123» solo si hay extensión; debajo, el móvil «(+34) 600 000 000» solo si se rellena; correo; y la vertical en negrita (Colegio Tajamar, Tajamar FP + Professional Education, Club Deportivo Tajamar, Fundación Tajamar, Alumni Tajamar o, solo si no encaja ninguna, Tajamar), «Calle Pío Felipe 12», «28038 Vallecas Madrid» y www.tajamar.es en 9 pt. Teléfonos en gris-80 (#333333); correo y web en negro subrayado, nunca en el azul por defecto del gestor de correo. El aviso legal va debajo, en Verdana 8 px gris-60 (#666666), con solo «AVISO LEGAL» en negrita: en la columna del texto si hay imagen de área, o a todo el ancho si solo va el escudo. Texto del aviso: «AVISO LEGAL. Este mensaje contiene información confidencial cuya divulgación está prohibida por la normativa europea vigente y se dirige exclusivamente a quien figura como su destinatario. Si usted no es el destinatario, le rogamos que nos lo comunique y destruya el mensaje y sus anexos. Si no desea seguir recibiendo comunicaciones, por favor, envíenos un mensaje a dpo@tajamar.es». «CONFIDENCIALIDAD: Este email es confidencial y para uso exclusivo de su destinatario». Generador en https://brand.tajamar.es/#firma.
- **Redes sociales:** avatar con el escudo oficial solo; el emisor ya va en el nombre de la cuenta. Si hace falta el logotipo, versión vertical. El logotipo puede ir en la imagen de cabecera. Hashtag #libresypunto.
- **Cierre audiovisual:** fondo de color corporativo pleno; la gaviota entra volando y se posa, forma el escudo y aparece el logotipo. Es una propuesta abierta a interpretación.

### Publicaciones

- **Comunicación externa (carteles, folletos, anuncios):** escudo y logotipo, cada uno en un lugar distinto de la pieza. Titulares expresivos en Rockwell; datos y texto en Avenir. En folletos, el escudo firma cada página arriba a la izquierda.
- **Revista Puente:** portada de formato fijo con cabecera cambiante (logotipos hechos a medida por concurso interno de alumnos). Firma siempre en el mismo sitio: escudo + «REVISTA PUENTE» en Avenir Black mayúsculas + «Colegio Tajamar» en Avenir Book. Interior moderno y atrevido: cambios de orientación, ilustraciones de alumnos, textos torcidos. Cada página par lleva arriba a la izquierda el escudo y «Revista Puente». Titulares destacados en Rockwell; el resto en Avenir.

### Espacios

- **Cartelería interna:** escudo arriba a la izquierda sobre masa de color, con el logotipo en negativo. Variante con borde blanco y el escudo en negro o en versión libre. Ilustraciones y mano alzada con libertad, respetando el aire del escudo.
- **Señalética:** dos cuadrantes, uno en color corporativo (o tinta) con el escudo en blanco y otro blanco con el nombre del despacho o sala en Avenir. Sin distinguir áreas, cargos ni despachos. En lugares singulares, escudo libre, ilustración o fondo de texto.
- **El centro:** murales, grafitis, mesas pintadas, paredes de post-it, concursos de alumnos. En los lugares principales, la marca o el escudo solos, sin más mensaje.
- **Uniforme:** escudo bordado en blanco en jerséis y uniformes azules. Equipaciones deportivas: escudo y logotipo en espacios propios de cada prenda, caso a caso.
- **Merchandising:** el escudo funciona en sudaderas, gorros de piscina, gafas, polos, camisetas de colores, mochilas, tazas, estuches, cuadernos, postales con fotos históricas… Las iniciativas solidarias son bienvenidas.

## Archivos oficiales

Todos están en https://brand.tajamar.es/#descargas:

- Kit completo, con SVG y PNG transparente de 2000 px: https://brand.tajamar.es/descargas/tajamar-kit-de-marca.zip
- Logos sueltos, con su dirección completa:

| Archivo | SVG (vector, también legible como texto) | PNG transparente de 2000 px |
|---|---|---|
| tajamar-educacion-infantil-horizontal | https://brand.tajamar.es/logos/svg/tajamar-educacion-infantil-horizontal.svg | https://brand.tajamar.es/logos/png/tajamar-educacion-infantil-horizontal.png |
| tajamar-educacion-infantil-vertical | https://brand.tajamar.es/logos/svg/tajamar-educacion-infantil-vertical.svg | https://brand.tajamar.es/logos/png/tajamar-educacion-infantil-vertical.png |
| tajamar-escudo-blanco | https://brand.tajamar.es/logos/svg/tajamar-escudo-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-escudo-blanco.png |
| tajamar-escudo-libre-boli | https://brand.tajamar.es/logos/svg/tajamar-escudo-libre-boli.svg | https://brand.tajamar.es/logos/png/tajamar-escudo-libre-boli.png |
| tajamar-escudo-libre-boli-blanco | — | https://brand.tajamar.es/logos/png/tajamar-escudo-libre-boli-blanco.png |
| tajamar-escudo-libre-brochazo | https://brand.tajamar.es/logos/svg/tajamar-escudo-libre-brochazo.svg | https://brand.tajamar.es/logos/png/tajamar-escudo-libre-brochazo.png |
| tajamar-escudo-libre-brochazo-blanco | — | https://brand.tajamar.es/logos/png/tajamar-escudo-libre-brochazo-blanco.png |
| tajamar-escudo-libre-spray | — | https://brand.tajamar.es/logos/png/tajamar-escudo-libre-spray.png |
| tajamar-escudo-libre-spray-blanco | — | https://brand.tajamar.es/logos/png/tajamar-escudo-libre-spray-blanco.png |
| tajamar-escudo-negro | https://brand.tajamar.es/logos/svg/tajamar-escudo-negro.svg | https://brand.tajamar.es/logos/png/tajamar-escudo-negro.png |
| tajamar-fp-professional-education | https://brand.tajamar.es/logos/svg/tajamar-fp-professional-education.svg | https://brand.tajamar.es/logos/png/tajamar-fp-professional-education.png |
| tajamar-fp-professional-education-blanco | https://brand.tajamar.es/logos/svg/tajamar-fp-professional-education-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-fp-professional-education-blanco.png |
| tajamar-fundacion-horizontal-blanco | https://brand.tajamar.es/logos/svg/tajamar-fundacion-horizontal-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-fundacion-horizontal-blanco.png |
| tajamar-fundacion-horizontal-negro | https://brand.tajamar.es/logos/svg/tajamar-fundacion-horizontal-negro.svg | https://brand.tajamar.es/logos/png/tajamar-fundacion-horizontal-negro.png |
| tajamar-fundacion-vertical-blanco | https://brand.tajamar.es/logos/svg/tajamar-fundacion-vertical-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-fundacion-vertical-blanco.png |
| tajamar-fundacion-vertical-negro | https://brand.tajamar.es/logos/svg/tajamar-fundacion-vertical-negro.svg | https://brand.tajamar.es/logos/png/tajamar-fundacion-vertical-negro.png |
| tajamar-isologo-horizontal-blanco | https://brand.tajamar.es/logos/svg/tajamar-isologo-horizontal-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-isologo-horizontal-blanco.png |
| tajamar-isologo-horizontal-negro | https://brand.tajamar.es/logos/svg/tajamar-isologo-horizontal-negro.svg | https://brand.tajamar.es/logos/png/tajamar-isologo-horizontal-negro.png |
| tajamar-libresypunto-blanco | https://brand.tajamar.es/logos/svg/tajamar-libresypunto-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-libresypunto-blanco.png |
| tajamar-logotipo-blanco | https://brand.tajamar.es/logos/svg/tajamar-logotipo-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-logotipo-blanco.png |
| tajamar-logotipo-negro | https://brand.tajamar.es/logos/svg/tajamar-logotipo-negro.svg | https://brand.tajamar.es/logos/png/tajamar-logotipo-negro.png |
| tajamar-revista-puente-negro | https://brand.tajamar.es/logos/svg/tajamar-revista-puente-negro.svg | https://brand.tajamar.es/logos/png/tajamar-revista-puente-negro.png |
| tajamar-vertical-blanco | https://brand.tajamar.es/logos/svg/tajamar-vertical-blanco.svg | https://brand.tajamar.es/logos/png/tajamar-vertical-blanco.png |
| tajamar-vertical-negro | https://brand.tajamar.es/logos/svg/tajamar-vertical-negro.svg | https://brand.tajamar.es/logos/png/tajamar-vertical-negro.png |

- Tokens de diseño (JSON): https://brand.tajamar.es/descargas/tajamar-tokens.json
- Paleta (CSV): https://brand.tajamar.es/descargas/tajamar-paleta.csv

Para cualquier duda, el contacto es la Dirección o el Departamento de Comunicación.
