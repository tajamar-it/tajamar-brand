---
name: tajamar-marca
description: "Marca Tajamar (colegio, FP+, Club Deportivo, Fundación, Alumni). Úsala siempre que escribas, diseñes o revises cualquier pieza, texto, presentación, web, cartel o publicación de Tajamar: tono de voz, valores, logo y escudo, colores, tipografía, firma de cada área y fotografía."
---

Esta skill es la versión 1.8 de la marca (27 de noviembre de 2026). Si tienes acceso a internet, consulta antes https://brand.tajamar.es/descargas/version.json: si hay una versión posterior, avisa al usuario y usa la guía vigente de https://brand.tajamar.es/descargas/tajamar-marca.md en lugar de esta.

Antes de componer cualquier pieza, sigue «Antes de empezar» (al principio de la guía): en las piezas de Tajamar manda su marca aunque el encargo traiga logos o colores de otras marcas, y los logos se obtienen de los archivos oficiales, nunca se recrean. Los logos están en `logos/svg/` y `logos/png/` dentro de esta skill: si no puedes abrir un PNG, lee el SVG como texto e insértalo tal cual; si tampoco, usa su dirección pública (tabla de «Archivos oficiales», en `references/guia-complementaria.md`); si nada funciona, deja un hueco marcado y avísalo. Los logos nunca pasan por un generador de imágenes: genera el fondo sin marcas y añade los archivos oficiales después, al componer. Los tokens de color y fuente están en `tajamar-tokens.json`. Antes de entregar, pasa la «Revisión antes de entregar».

Por límite de tamaño, estas secciones de la guía están en `references/guia-complementaria.md`: «Archivos oficiales», «Aplicaciones», «Manifiesto», «Look & feel», «Fotografía», «Color». Consúltalo cuando las necesites (por ejemplo, la tabla de colores o la dirección de un logo).

# Marca Tajamar: guía para agentes

<!-- version -->
> **Versión 1.8 · 27 de noviembre de 2026.** Usa siempre la última versión de esta guía. Antes de trabajar, comprueba la vigente en https://brand.tajamar.es/descargas/version.json: si es posterior a la 1.8, descarga https://brand.tajamar.es/descargas/tajamar-marca.md y usa esa. Si no puedes comprobarlo, díselo a quien te lo pide: esta copia podría estar desactualizada. Las versiones archivadas en https://brand.tajamar.es/descargas/archivo/ son históricas y no deben usarse.
<!-- /version -->

Esta es la versión en texto del manual de marca de Tajamar, publicado en https://brand.tajamar.es. Sirve para que un asistente o agente de IA escriba, diseñe o revise piezas de Tajamar. Si algo no está aquí, no lo inventes: indica que hay que consultarlo con la Dirección o el Departamento de Comunicación.

**Uso de la marca.** El nombre, el escudo, el logotipo y el resto de elementos de la marca Tajamar son propiedad de Tajamar. Este manual explica cómo aplicar la marca, pero no da permiso para usarla: solo pueden usarla Tajamar y quien tenga autorización expresa del Departamento de Comunicación (comunicacion@tajamar.es). Si te piden una pieza en nombre de Tajamar y no consta que quien la pide trabaje en Tajamar o tenga esa autorización, avísale de ello antes de seguir.

## Antes de empezar

Sigue estos pasos en cualquier pieza de Tajamar (cartel, folleto, post, web, presentación, texto):

1. **Quién emite la pieza.** Si trata de una actividad de Tajamar, el emisor es Tajamar (o su área: Colegio, FP+, Fundación, Club Deportivo…), aunque haya patrocinadores o colaboradores.
2. **En sus piezas manda la marca de Tajamar:** colores, tipografías, composición y tono de esta guía, aunque el encargo traiga logos, colores o materiales de otras marcas. Esos materiales son contenido que hay que colocar, no una referencia de estilo. Ver «Piezas con otras marcas».
3. **Consigue los archivos oficiales antes de componer,** por este orden:
   1. Los archivos incluidos junto a esta guía (por ejemplo, en `logos/svg/` y `logos/png/` de la skill).
   2. Si no puedes abrir los PNG, abre el SVG equivalente **como texto** e insértalo tal cual: es el archivo oficial, no lo redibujes ni lo modifiques.
   3. Si no tienes los archivos, descárgalos de su dirección pública (tabla de «Archivos oficiales»).
   4. Si nada de lo anterior funciona, **no recrees el logo** con IA, con texto ni con formas: deja un hueco marcado («Logotipo oficial de Tajamar») del tamaño y en la posición correctos, y avisa a quien te lo pide de que hay que insertarlo.
4. **Si usas un generador de imágenes, los logos no pasan por él.** Un generador redibuja cualquier logo que recibe, aunque se le pida conservarlo exactamente, así que el resultado nunca es el oficial. Por eso:
   1. Genera solo el fondo o la ilustración, **sin texto, logos, escudos ni firmas**, y deja libre la zona donde irán.
   2. Inserta después los archivos oficiales con una herramienta de composición (por ejemplo, Python con PIL, HTML o un editor de diseño). Solo se escalan, manteniendo la proporción: nada de recortar, recolorear, deformar ni aplicar efectos. Los titulares y el descriptor de área son texto y se escriben en este mismo paso, con la tipografía de la marca.
   3. Una vez insertado el logo, la pieza no vuelve a pasar por el generador. Si hay que cambiar algo, cambia el fondo y compón de nuevo.
5. **No inventes datos.** Si falta algo esencial (fecha, hora, lugar, inscripción), pregunta o deja un marcador visible.
6. **Si el encargo choca con una regla de esta guía,** dilo y propón una alternativa que la cumpla.
7. **Antes de entregar, pasa la «Revisión antes de entregar»** del final.

## Qué es Tajamar

Una sola marca firma todo lo que hace Tajamar: Colegio, FP + Professional Education, Club Deportivo, Fundación Tajamar y Alumni. Cada área tiene su propia expresión, pero ninguna tiene logo nuevo. Tajamar existe desde 1958 y está en Vallecas (Madrid).

- **Lema:** «Somos distintos».
- **Firma verbal:** libresypunto™, que también se lee «libres y punto». Hashtag: #libresypunto.
- **Nombre:** se escribe «Tajamar». El logotipo es «tajamar.», en minúsculas y con punto final, pero eso es solo el dibujo del logotipo. En texto corrido escribe siempre «Tajamar».

| Área | Carácter |
|---|---|
| Colegio | Cercano a las familias, serio sin ser rígido. |
| FP + Professional Education | Adulta y profesional, con el negro como base. |
| Club Deportivo | Esfuerzo, constancia y equipo. |
| Fundación Tajamar | Credibilidad, personas reales y servicio. |
| Alumni | Ayer. Hoy. Siempre. |

## Valores: cuatro territorios

Los tres primeros marcan el tono. El cuarto añade reto y mirada hacia fuera.

| Territorio | Rasgos | Frase | Sí | No |
|---|---|---|---|---|
| Idealistas | espirituales, universales, optimistas, alegres, holísticos, verdaderos | No hemos dejado de soñar. | Una visión ambiciosa y positiva de las personas. | Mensajes cliché, decir solo lo socialmente «adecuado» o soñar tonterías. |
| Abiertos | espontáneos, sencillos y honestos, familiares y accesibles, humildes, generosos, fáciles | Siempre damos algo. | Información, una invitación, una historia útil para quien lee. | Decir que eres abierto en vez de demostrarlo. |
| Libres | creativos, comunicadores, responsables, humanistas y serios, comprometidos, personalizados | Oiga, que yo soy yo. | Naturalidad, frases relajadas, personas con nombre propio. | Escribir mal porque sí: hay que ser muy educado para ser libre. |
| Fronterizos | modernos y cool, anexionadores, challenger, adaptables y atrevidos, heterogéneos y diversos, cosmopolitas | Cruzar el río es cruzar el río. | Buscar inspiración al otro lado y atreverse. | Ser exagerados, alborotadores o agresivos. |

## Tono de voz

Tajamar suena humano, claro, seguro, optimista, abierto, expresivo y distintivo. Puede ser formal cuando toca, pero nunca frío ni burocrático.

Ejemplos:
- «Bueno, no nos engañemos. En realidad este colegio es de la gente».
- «Aquí, desde 1958, si quieres, puedes».
- «Nos dieron la corbata de Alfonso X el Sabio. (Pero no nos la ponemos)»
- «Bienvenido al mundo real».
- «El primer centro de economía colaborativa de Madrid».

Si nuestro tono de voz fuese una historia, sería Gandhi; un personaje famoso, la gente; una cita, «Tenemos demasiadas cosas y no suficientes formas» (Flaubert); una marca, Coca-Cola.

### Al escribir

- Empieza por lo más interesante o útil, no por un preámbulo.
- Usa sustantivos concretos y verbos activos: personas, acciones y detalles reales.
- Escribe para el lector, no sobre lo maravillosa que es la institución.
- Sé elegante al hablar en nombre de Tajamar y más sencillo en comentarios y respuestas.
- Con las familias, lo práctico va primero: qué, cuándo, dónde y qué hay que hacer.

### Expresiones que no se usan

- «una experiencia única e inolvidable»
- «el futuro empieza aquí»
- «damos forma a tus sueños»
- «el mejor», «líder», «referente»
- «transformar vidas»

### Prueba «libres y punto»

Antes de entregar un texto, comprueba los cinco puntos. Si falla alguno, reescríbelo: o es libre, o no lo es.

1. No podría firmarlo otro centro cambiando solo el nombre.
2. Da algo al lector: información, una invitación o un detalle útil.
3. Suena a una persona hablando con naturalidad.
4. Es ambicioso sin clichés y abierto sin decir que lo es.
5. Podría cerrarse con «libres y punto» sin que chirríe.

## Logotipo y escudo

- **Escudo:** una «T» que dibuja el tajamar de un barco con una gaviota encima. Va preferentemente a la izquierda, con espacio libre a su derecha para que la gaviota salga volando. Se construye sobre una retícula modular de X, con ajustes de ½X.
- **Logotipo:** «tajamar.», con punto final. Se construye con un módulo X y mide 6X de alto.
- **Isologo horizontal y versión vertical:** escudo y logotipo unidos en una sola pieza.

### Cómo firmar

- Lo preferido: escudo y logotipo por separado en la misma pieza, cada uno en su sitio (por ejemplo, escudo arriba a la izquierda y logotipo abajo a la derecha). Da más libertad que las versiones unidas.
- Lo ideal es que la marca vaya sobre color o foto.
- El escudo puede ir solo en papelería, redes sociales y comunicación interna. En comunicación externa, siempre con el logotipo en el mismo plano.
- Isologo horizontal y versión vertical: cuando un tercero usa la marca, en patrocinios o cesiones, al convivir con marcas que no controlamos y cuando el tamaño obliga.

### Qué versión va según el fondo

| Fondo | Versión |
|---|---|
| Blanco o claro (gris-10, gris-20, ladrillo-4, ladrillo-5, cielo-5…) | Negra (positivo) |
| Negro | Blanca (negativo) |
| Color medio u oscuro (cielo-2, ladrillo-1, verde-1…) | Blanca. Es la opción preferida sobre color. |
| Foto | Blanca. Elige fotos en las que funcione; si la foto es muy clara, negra. |

### Área de protección y tamaños mínimos

- Escudo: el área de protección la marca la «T» interior del escudo.
- Logotipo: como mínimo, la altura de la «T» alrededor de todo el logotipo.
- Cuanto más aire, mejor. El área de protección la respetan imágenes y textos; solo la invaden las versiones especiales.
- Si el escudo no puede ir a la izquierda, deja espacio suficiente a su derecha y no lo pegues al margen.
- No existen versiones del escudo ni del logotipo en otros colores, ni se pueden crear.

| Pieza | Mínimo |
|---|---|
| Escudo | 5 mm |
| Logotipo | 23 mm de ancho |
| Versión vertical | 10 mm de ancho |
| Isologo horizontal | 25 mm de ancho |

### Nunca

- Redibujar, deformar, girar o recolorear el escudo o el logotipo.
- Cortar el escudo por ningún lado.
- Usar el escudo aislado en comunicación externa sin el logotipo en el mismo plano.
- Invadir el área de protección.
- Poner el logotipo en un color que no sea negro o blanco.
- Generar, vectorizar o recrear el logo: usa siempre los archivos oficiales.

### Escudos libres

Hay tres: boli, brochazo (en masa o «descascarillado») y spray. Son solo para comunicación **interna** (ambientación, decoración, presentaciones, cartelería, señalética). No sustituyen al escudo oficial en comunicación externa y no se usan de forma masiva. Las versiones nuevas se acuerdan con la Dirección del centro.

## Piezas con otras marcas

**Cuando Tajamar organiza o emite** (por ejemplo, un evento de Tajamar con patrocinadores o colaboradores):

- La pieza es de Tajamar: colores, tipografías, composición y tono de Tajamar. **No se usan los colores, tipografías ni el estilo del patrocinador.**
- Tajamar firma como siempre: escudo y logotipo. Con varias marcas o poco espacio, isologo horizontal o versión vertical, que existen precisamente para convivir con otras marcas.
- Los logos de terceros van juntos en una zona propia, normalmente abajo, con un rótulo en Avenir (Montserrat en web): «Patrocina», «Colabora» o «Con el apoyo de».
- Siempre su archivo original, sin recolorear ni deformar. Si no se lee bien sobre el fondo, va sobre una banda blanca o en su versión oficial en negro o blanco.
- Ningún logo de tercero es más grande ni más visible que la marca de Tajamar: como referencia, no más alto que el logotipo de Tajamar.
- Nunca forman un bloque con la marca de Tajamar.

**Cuando Tajamar patrocina o colabora en la pieza de otro:** la pieza es del tercero. Tajamar aparece con su isologo horizontal o su versión vertical oficial, en negro o blanco, en el espacio que le reserven.

**Si se organiza a medias o hay dudas,** consulta con el Departamento de Comunicación antes de decidir qué marca pesa más.

## Tipografía

| Papel | Original (con licencia) | Pesos | Sustituta web | Sustituta en documentos internos | Reglas |
|---|---|---|---|---|---|
| Titulares de gran formato y frases con el tono de la marca | Rockwell | Regular y Bold | Rokkitt | Courier | Nunca en cursiva ni en textos largos. Caja alta solo en destacados o palabras cortas como «BIG» o «GANAR». |
| Principal: titulares informativos y texto corrido | Avenir | Light, Book y Black, con sus oblicuas | Montserrat | Verdana | Titular mayor y con más peso; encabezado intermedio; texto más pequeño y ligero. Ideas principales en negrita; neologismos y sentidos figurados en cursiva. |
| Arquitectura de marca: descriptores de área | ITC Franklin Gothic | Medium; Demi solo para Fundación | Libre Franklin, como aproximación | Arial | — |

- **libresypunto:** siempre en Rockwell, minúsculas y todo junto. Funciona como un logotipo: usa el archivo oficial y no cambies su composición.
- Las fuentes originales tienen licencia y no se distribuyen: hay que pedirlas al Departamento de Comunicación. Para web, usa Google Fonts: Montserrat, Rokkitt y Libre Franklin.

## Arquitectura de marca

Tajamar es una marca única: toda la organización se presenta bajo ella y sus áreas suman a esa marca. Las áreas se nombran en texto junto a la marca. Solo FP+, Infantil y Fundación tienen firma propia aprobada.

| Nivel | Quién | Cómo firma |
|---|---|---|
| 0 · Marca única | Tajamar | Escudo y logotipo. Excepcionalmente, isologo o versión vertical. |
| 1 · Institucional | Fundación Tajamar | Extensión de la marca con firma propia. Sus proyectos (Juventud, Jornadas Humanísticas…) van en texto. |
| 2 · Institucional y comercial | Colegio Tajamar | Infantil, Primaria, Secundaria y Bachillerato. Sus subáreas, en texto. |
| 2 · Institucional y comercial | Tajamar FP + Professional Education | FP+ no es Colegio, nunca: emite siempre «Tajamar», con el descriptor FP+ aparte. |
| Áreas | Club Deportivo, Alumni, AMPA | Marca Tajamar más el nombre del área en texto, nunca logotipado. |

- **Colegio Tajamar:** es la marca Tajamar. Infantil, Primaria, Secundaria y Bachillerato firman como Colegio Tajamar. FP+ no es Colegio, nunca: firma como «Tajamar» con su descriptor.
- **Club Deportivo, Alumni y Escuela de Música:** usan la fórmula de área. El escudo va arriba a la izquierda de la pieza y el descriptor arriba a la derecha de la pieza, alineado con la parte superior del escudo y bien separado de él, en Franklin Gothic Medium negro. El descriptor es solo el nombre del área («Club Deportivo», «Alumni», «Escuela de Música»), sin «Tajamar»: ya lo dicen el escudo y el logotipo. **No forman un bloque ni una firma conjunta: cada uno va en su extremo** (en un díptico, el escudo en el margen izquierdo y «Club Deportivo» en el derecho). El logotipo firma en otro lugar de la pieza (contraportada, abajo a la derecha). Los productos, como «500 km», en Rockwell. Alumni prefiere las gamas más nobles: tierras y oscuros.
- **FP + Professional Education:** descriptor oficial en ITC Franklin Gothic Medium, con un «+» dibujado a medida con la base constructiva del escudo; la pastilla deja 2X a los lados y 1,5X arriba y abajo. Sobre pastilla negra en portadas y piezas destacadas; en el resto, negro o blanco sobre foto o color. Nunca en color y nunca junto al logotipo: emite siempre Tajamar (escudo y logotipo, o isologo). Look propio, más adulto y profesional, con el negro como base. Tiene tres familias, que se escriben siempre así y en este orden: Gráfica, Tech y Deporte (no «Informática» ni «Deportiva»); cada una puede tomar un color. Productos como IMPRE o PREDI, en Avenir Black y nunca logotipados.
- **Educación Infantil:** es la única área que puede firmar bajo el logotipo, con «Educación Infantil» en Franklin Gothic, también con las versiones especiales. Queda mejor sobre color o foto. Admite ilustraciones y piezas más divertidas.
- **Fundación Tajamar:** no usa el logotipo. Firma con el escudo y «Fundación Tajamar» en Franklin Gothic Demi, en vertical (bajo el escudo) u horizontal (a la derecha). Comunicación más formal, con fotos reales. Proyectos como Jornadas Humanísticas: nombre en Franklin Gothic Medium y titular en Avenir.
- **Siempre en texto, nunca con logotipo propio:** Juventud, Jornadas Humanísticas, AMPA Tajamar, Escuela de Música, Programa Excellence, las familias de FP+ (Gráfica, Tech, Deporte), IMPRE, PREDI y Revista Puente.

## Revisión antes de entregar

Si falla un punto, rehaz la pieza.

- **Emisor y marca:** la pieza es de Tajamar con sus colores, tipografías y composición; los logos de terceros, en su zona y sin mandar.
- **Logos:** el escudo y el logotipo se insertaron desde los archivos oficiales con una herramienta de composición y la pieza no volvió a pasar por un generador de imágenes. Que un logo se parezca al original no prueba que sea el oficial: cuenta cómo se insertó. Solo escalados en proporción, sin redibujar, deformar ni recolorear; versión correcta para el fondo; con su área de protección y por encima de los tamaños mínimos; escudo y logotipo por separado o la versión especial que toque; en comunicación externa, los dos en la misma pieza.
- **Arquitectura:** la firma del área es la correcta; FP+ nunca como Colegio; ningún área con logo propio inventado. En Club Deportivo, Alumni y Escuela de Música: escudo arriba a la izquierda, descriptor arriba a la derecha alineado con él, sin formar bloque, y el logotipo en otro lugar de la pieza.
- **Color y texto:** texto sobre blanco solo en tonos «texto»; sobre tonos «campo», texto negro.
- **Tipografía:** Rockwell/Rokkitt para titulares expresivos, Avenir/Montserrat para el resto.
- **Datos:** cada fecha, hora, lugar, cifra y dirección viene del encargo; lo que falte está marcado.
- **Voz:** empieza por lo útil, sin clichés; pasa la prueba «libres y punto».
- **Fotos:** reales y con permisos; ninguna generada con IA presentada como real.
